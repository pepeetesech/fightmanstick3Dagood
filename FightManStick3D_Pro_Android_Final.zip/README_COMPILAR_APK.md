# FightManStick 3D — Compilación Android APK (Debug Rápido + Release Seguro)

Este paquete conserva íntegro el juego original en `www/index.html` (`com.fightmanstick3d.pro`) y separa la compilación en **dos workflows independientes de GitHub Actions**:

- **`.github/workflows/build-android-debug.yml`**: compila una **APK Debug instalable** sin necesidad de configurar ningún Secret ni Keystore (se ejecuta automáticamente al hacer `push` a `main`/`master` o manualmente desde Actions).
- **`.github/workflows/build-android-release.yml`**: compila una **APK Release firmada** con Keystore persistente vía GitHub Secrets (solo se ejecuta manualmente o al crear un tag `v*`).

## 1. Obtener tu primera APK Debug instalable (Sin Secrets ni Keystore)

1. Crea un repositorio en GitHub y sube todos los archivos de este ZIP manteniendo sus carpetas (`www/`, `assets/`, `.github/workflows/`, `package.json`, `capacitor.config.json`, `.gitignore`).
2. Al subir a `main` (o al pulsar **Run workflow** en **Actions > Compilar FightManStick 3D APK (Debug - Sin Secrets)**), GitHub Actions ejecutará:
   - `npm install`, `npx cap add android`, `npx @capacitor/assets generate --android` y `npx cap sync android`.
   - Configuración y verificación automática de `android:screenOrientation="sensorLandscape"` en `AndroidManifest.xml` y `applicationId "com.fightmanstick3d.pro"` en `build.gradle`.
   - Compilación con `./gradlew assembleDebug`.
3. Al terminar (~3 minutos), abre la ejecución completada en **Actions**, baja a la sección **Artifacts** y descarga `FightManStick3D-Debug-APK-build-N` (contiene `FightManStick3D-Debug-buildN.apk`).

## 2. Instalar la APK Debug en tu Android

1. Descomprime el archivo descargado de GitHub Actions en tu teléfono para obtener `FightManStick3D-Debug-buildN.apk`.
2. Toca el archivo `.apk` desde tu gestor de archivos.
3. Si Android lo solicita, toca **Configuración** y activa **Permitir desde esta fuente / Fuentes desconocidas**.
4. Pulsa **Instalar** y luego **Abrir**.

## 3. Compilar APK Release firmado para producción (cuando quieras publicar actualizaciones)

Cuando ya hayas probado el juego y quieras firmar con un Keystore persistente:

1. Genera tu Keystore una sola vez:
   ```bash
   keytool -genkey -v -keystore fightmanstick-release.keystore -alias fightmanstick -keyalg RSA -keysize 2048 -validity 10000
   ```
2. Conviértelo a Base64 (`base64 -w 0 fightmanstick-release.keystore > keystore_base64.txt` en Linux/Termux o `[Convert]::ToBase64String([IO.File]::ReadAllBytes("fightmanstick-release.keystore"))` en PowerShell).
3. En GitHub, ve a **Settings > Secrets and variables > Actions** y crea estos 4 Secrets:
   - `ANDROID_KEYSTORE_BASE64`
   - `ANDROID_KEYSTORE_PASSWORD`
   - `ANDROID_KEY_ALIAS`
   - `ANDROID_KEY_PASSWORD`
4. Ejecuta manualmente **Actions > Compilar FightManStick 3D APK (Release Firmado)** o crea un tag `v1.0.0`.
